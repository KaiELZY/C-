/*
	ImageClass.h
	Author:		Zachary Liong
	Purpose:	Creates a Image Class that will be used
				to hide the sensitive data from the ImageLib.h
				and be used in the Main.cpp
*/
#include "ImageLib.h"
using namespace std;
class Image
{
public:
	//default constructor
	Image() {
		mImage = this->createBlankImage(0, 0);
	}

	//copy constructor
	Image(const Image& copy);

	//destructor
	~Image();
	 
	Image& operator=(const Image& pic);

	void savePicture();

	int getRows() const;

	int getColumns() const;

	int getBlue(image pic, int r, int c);

	void setBlue(pixel& pix, int r, int c, int mod);

	int getRed(image pic, int r, int c);

	void setRed(pixel& pix, int r, int c, int mod);

	image ReadFromFile(string fileName);

	pixel& getPixel(int r, int c);

	pixel setPixel(int r, int c, image target);

	image createBlankImage(int r, int c);

	//overload <<
	friend ostream& operator<<(ostream& ostr, const Image& im);
	
	//overload <
	bool operator<(const Image&) const;

	//overload >
	bool operator>(const Image&) const;

	//overload ==
	bool operator==(const Image&) const;

	//overload !=
	bool operator!=(const Image&) const;

	//mirror Method
	Image mirrorImage(const Image& input);
private:
	
	image mImage;
};