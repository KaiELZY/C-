/* 
	Main.cpp
	Author :	Zachary Liong
	Purpose :	This is the driver class that uses the Image Class
				to read, change, and output an image gif.
*/
#include "ImageClass.h"
#include <iostream>

using namespace std;
//forward delaration
void ModifiedImage(Image& im);
long countDifferentPixels(Image original, Image modPic);
/*
	Main()
	Precondition:	test2.gif exists and a valid GIF file
	Postcondition:	It will create an output.gif and output
					the amount of pixel difference between
					output.gif and the newly read output.gif
					variable
*/
int main()
{
	Image mainFile;

	mainFile.ReadFromFile("test2.gif");

	//a fail safe if target file is not found
	if (mainFile.getRows() == 0)
	{
		cout << "Unable to open file" << endl;
		return -1;
	}

	Image modInput(mainFile);
	
	Image mirror = modInput.mirrorImage(mainFile);

	
	ModifiedImage(mirror);

	mirror.savePicture();

	Image modifiedInput;
	modifiedInput.ReadFromFile("output.gif");

	if (mirror == modifiedInput)
	{
		cout << "Both images are the same and no difference";
	}
	else
	{
		cout << countDifferentPixels(mirror, modifiedInput) << " different pixels" << endl;
	}
	return 0;
}

/*
	ModifiedImage:	Takes an Image class and changes the pixels in 
					private data of image
	Precondition:	Takes in an Image class, assuming that there is a valid
					and existing image in its data, access the 2d pixel array
					and change the values of the pixel.
	Postcondition:	Set and change the row and pixel of blue and red and returns
					the modified image back into the Image Class's private image
					data
*/
void ModifiedImage(Image& im)
{
	for (int row = 0; row < im.getRows(); row++)
	{
		for (int col = 0; col < im.getColumns(); col++)
		{
			im.setBlue(im.getPixel(row, col), row, col, 7);
			im.setRed(im.getPixel(row, col), row, col, 9);
			
		}
	}
}

/*
	countDifferentPixels:	Takes two Image classes and compares their images' 
							pixels and returns a count based on differences
	Precondition:			Assumes that both Images are initialized, have 
							the same rows and columns of both images. Long
							count would be set to 0 when this method is called
	Postcondition:			Produces and returns a long variable called count,
							based on the amount of pixels that differ
*/
long countDifferentPixels(Image original, Image modPic)
{
	long count = 0;
	if (original.getRows() == modPic.getRows() && original.getColumns() == modPic.getColumns())
	{
		for (int i = 0; i < original.getRows(); i++)
		{
			for (int j = 0; j < original.getColumns(); j++)
			{
				//this statement will check for differences in the original and modded image and 
				//counts each different pixel between the two.
				if (original.getPixel(i,j).blue != modPic.getPixel(i,j).blue ||
					original.getPixel(i,j).red != modPic.getPixel(i,j).red ||
					original.getPixel(i,j).green != modPic.getPixel(i,j).green)
				{
					//keep count of what pixels differ from original
					count++;
				}
			}
		}
	}
	return count;
}
