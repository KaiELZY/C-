#include "ImageClass.h"
#include "ImageLib.h"

Image original(image& copy)
{
	 mImage = copy;
}

image ReadFromFile(string fileName)
{
	return ReadGIF(fileName);
}