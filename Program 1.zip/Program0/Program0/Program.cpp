/* Program0.cpp
   Author:	Zachary Liong
   Purpose:	Reads a test image (GIF), then
			creates a modified version of the input
			and outputs the result "output.gif"
*/
#include "ImageLib.h"
// this is java's system.output version of C++
#include <iostream> 

//In C++, methods needs to be made before the method is called. However, you must make forward declaration

//All forward declaration 
void modifiedImage(image& modInput);
void modifiedPixel(pixel& pix, int row, int col);
void mirrorImage(image& pic);
void countPixels(image original, image modPic, int& counter);
//main()
/* Precondition:	test.gif exists and is a valid GIF Image
   Postcondition:	output.gif will be written and it contains
					a lighter, reversed version of the image 
					test.gif
*/

int main()
{
	//read test image from file
	image input = ReadGIF("test1.gif");
	//a fail safe if the GIF image is invalid or does not exist
	if (input.rows == 0)
	{
		cout << "Unable to open file" << endl;
		return -1;
	}
	//Program one's main function of making pixels look more lighter
	modifiedImage(input);
	//moves all pixels from left to right and right to left
	mirrorImage(input);
	//store it to a new variable for this reversed modified input
	image reversalImage = input;
	//saves the current modified input to an output.gif
	WriteGIF("output.gif", input);
	//create a new variable to store a new image and a int count varaible for diff. pixels
	image modifiedInput = ReadGIF("output.gif");
	int count = 0;
	//this variable will be used to create two different responses if the two image are the same
	bool difference = false;
	//execute the countPixel method to check if any or all pixels differ from its original image
	countPixels(reversalImage, modifiedInput, count);
	if (count > 0)
	{
		difference = true;
	}
	//Outputs the results
	cout << "The dimension of the image are: " << input.rows << " rows by " << input.cols << " columns" << endl;
	if (difference == true)
	{
		cout << "Yes, there are differences between the input and output GIFs, about " << count << " pixels!" << endl;
	}
	else
	{
		cout << "No, there are no differences between the input and output GIFs (exactly the same)!" << endl;
	}
	//Java automatically removes the unwanted data after, but C++ doesn't. So we programmers must do it ourselves
	DeallocateImage(input);
	DeallocateImage(modifiedInput);
	return 0;
}


/*
	modifiedImage:	Takes an input GIF image to create a lighter image
	Precondition:	The inputted image has to be GIF and has both rows and cols of pixels allocated
	Postcondition:	Produces a image that that decrease the blue color, while increasing the green to 
					make a lighter image
*/
void modifiedImage(image& modInput)
{
	for (int row = 0; row < modInput.rows; row++)
	{
		for (int col = 0; col < modInput.cols; col++)
		{
			modifiedPixel(modInput.pixels[row][col], row, col);
		}
		
	}
}
/*
	modifiedPixel:	Changes the blue and red colors of the pixels based 
					on mod 7 and 9, respectively
	Precondition:	None
	Postconditions:	Each red and blue color band of the inputted pixel (pix)
					will be lighter by a small margin
*/
void modifiedPixel(pixel& pix, int row, int col)
{
	//set variables to avoid using magic numbers and to reduce the clutters
	const int ROW_CONSTANT = 7;
	const int COLUMN_CONSTANT = 9;
	int rowSubtraction = row % ROW_CONSTANT;
	int colSubtraction = col % COLUMN_CONSTANT;
	//creating if statements for overflow and underflow with the appropriate results (rows)
	if ((pix.blue - rowSubtraction) < 0)
	{
		rowSubtraction = 0; //ensures the pix.blue does not go under 0 - underflow
		pix.blue = pix.blue - rowSubtraction;
	}
	else if ((pix.blue - rowSubtraction) > 255)
	{
		rowSubtraction = 255; //ensures the pix.blue will not go over 255 - overflow
		pix.blue = pix.blue - rowSubtraction;
	}
	else
	{
		// if all if-statements are false, then resume as normal
		pix.blue = pix.blue - rowSubtraction;
	}

	//creating if statements for overflow and underflow with the appropriate responses (columns)
	if ((pix.red + colSubtraction < 0))
	{
		colSubtraction = 0;
		pix.red = pix.red + colSubtraction;
	}
	else if ((pix.red + colSubtraction > 255))
	{
		colSubtraction = 255;
		pix.red = pix.red + colSubtraction;
	}
	else
	{
		pix.red = pix.red + colSubtraction;
	}
}
/*
	mirrorImage:	Swaps the pixels around, the left pixels switch with the right pixels
	Preconditions:	Takes a valid, GIF image with rows and columns of pixels allocated
	Postconditions:	Produces an mirror image of the input image flipped left to right 
*/
void mirrorImage(image& pic)
{
	for (int row = 0; pic.rows > row; row++)
	{
		for (int col = 0; pic.cols / 2 > col; col++)
		{
			//this saves the current selected pixel (original)
			pixel temp = pic.pixels[row][col];
			//this will swap the pixels around using columns to create the mirror images
			int swapColumns = pic.cols - col - 1;
			pic.pixels[row][col] = pic.pixels[row][swapColumns];
			pic.pixels[row][swapColumns] = temp;
		}
	}
}
/*
	countPixels:	Compares the original image (modified) and re-read image for any differences
	Precondition:	Assumes that images have the same row and column as the source image that it is 
					going to compare. Integer counter starts at zero
	Postcondition:	Produces the amount of differences between the two images as int counter
*/
void countPixels(image original, image modPic, int& counter)
{
	//makes sure the count start at zero
	counter = 0;
	//this if statement ensures the the image and modified image have the same amount of pixels
	if (original.rows == modPic.rows && original.cols == modPic.cols)
	{
		for (int i = 0; i < original.rows; i++)
		{
			for (int j = 0; j < original.cols; j++)
			{
				//this statement will check for differences in the original and modded image and 
				//counts each different pixel between the two.
				if (original.pixels[i][j].blue != modPic.pixels[i][j].blue ||
					original.pixels[i][j].red != modPic.pixels[i][j].red ||
					original.pixels[i][j].green != modPic.pixels[i][j].green)
				{
					//keep count of what pixels differ from original
					counter++;
				}
			}
		}
	}
	else
	{
		cout << "The original and modfified image are not the same!" << endl;
	}
}




