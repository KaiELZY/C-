#include "RectangleClass.h"
#include "ImageClass.h"

//forward declaration
void drawImageInHalfSize( Image& main, Rectangle& r, Rectangle& rPrev, Image& target);
void drawFlippedImageInHalfSize(Image& main, Rectangle& r, Rectangle& rPrev, Image& target);
void fractal(Image& source, Rectangle& r, Rectangle& rPrev, Image& target);

/*
	main()
	Precondition:	None
	Postcondition:	Outputs the target image and save it into
					output.gif
*/
int main()
{
	
	Image test;
	test.ReadFromFile("test256.gif");
	Image target;
	target.createBlankImage(test.getRows(), test.getColumns());
	Rectangle original(0, test.getRows(), 0, test.getColumns());
	Rectangle currentDrawingRect (original);

	fractal(test, currentDrawingRect, original, target);
	
	
	target.savePicture();
}

/*
	fractal:		This method will recursively create the images smaller and flipped, while using
					rectangles passed in as its borders of the smaller images
	Precondition:	Assume that image (source) has both even rows and columns, and the target image 
					has the same dimensions as sources. Both images has to be initialized
	Postcondition:	Target image will be overwritten and output the appropriate image
*/

void fractal(Image& source, Rectangle& currentDrawingRect, Rectangle& imageRect, Image& target)
{
	if (currentDrawingRect.getMaxColumn() - currentDrawingRect.getFirstColumn() < 2 || currentDrawingRect.getMaxRow() - currentDrawingRect.getFirstRow() < 2)
	{
		return;
	}

	Rectangle rTopLeft(currentDrawingRect.getFirstRow(), currentDrawingRect.getFirstRow() + (currentDrawingRect.getMaxRow() - currentDrawingRect.getFirstRow()) / 2, currentDrawingRect.getFirstColumn(), currentDrawingRect.getFirstColumn() + (currentDrawingRect.getMaxColumn() - currentDrawingRect.getFirstColumn()) / 2);
	drawImageInHalfSize(source, rTopLeft, imageRect, target);

	Rectangle rBottomRight(currentDrawingRect.getFirstRow() + (currentDrawingRect.getMaxRow() - currentDrawingRect.getFirstRow()) / 2 + 1, currentDrawingRect.getMaxRow(), currentDrawingRect.getFirstColumn() + (currentDrawingRect.getMaxColumn() - currentDrawingRect.getFirstColumn()) / 2 + 1, currentDrawingRect.getMaxColumn());
	drawFlippedImageInHalfSize(source, rBottomRight, imageRect, target);
	
	Rectangle rBottomLeft(currentDrawingRect.getFirstRow() + (currentDrawingRect.getMaxRow() - currentDrawingRect.getFirstRow()) / 2 + 1, currentDrawingRect.getMaxRow(), currentDrawingRect.getFirstColumn(), currentDrawingRect.getFirstColumn() + (currentDrawingRect.getMaxColumn() - currentDrawingRect.getFirstColumn()) / 2 + 1);
	fractal(target, rBottomLeft, rTopLeft, target);

	Rectangle rTopRight(currentDrawingRect.getFirstRow(), currentDrawingRect.getFirstRow() + (currentDrawingRect.getMaxRow() - currentDrawingRect.getFirstRow()) / 2 + 1, currentDrawingRect.getFirstColumn() + (currentDrawingRect.getMaxColumn() - currentDrawingRect.getFirstColumn()) / 2 + 1, currentDrawingRect.getMaxColumn());
	fractal(target, rTopRight, rTopLeft, target);
}

/*
	drawImageInHalfSize:	This is to "shrink" the image by half of its original size
							and set the pixels into the target image
	Precondition:			Image should have even rows and columns and have valid pixels
	Postcondition:			target image will contain the shrinked image based on the 
							location of the previous
*/
void drawImageInHalfSize(Image& main, Rectangle& rDrawingArea, Rectangle& rPrev, Image& target)
{
	for (int row = rPrev.getFirstRow(); row < rPrev.getMaxRow() - 1; row += 2)
	{
		for (int col = rPrev.getFirstColumn(); col < rPrev.getMaxColumn() - 1; col += 2)
		{
			pixel p1 = main.getPixel(row, col);
			pixel p2 = main.getPixel(row + 1, col);
			pixel p3 = main.getPixel(row, col + 1);
			pixel p4 = main.getPixel(row + 1, col + 1);

			int avgRed = (p1.red + p2.red + p3.red + p4.red) / 4;
			int avgGreen = (p1.green + p2.green + p3.green + p4.green) / 4;
			int avgBlue = (p1.blue + p2.blue + p3.blue + p4.blue) / 4;

			int rowOffset = (row - rPrev.getFirstRow()) / 2;
			int colOffset = (col - rPrev.getFirstColumn()) / 2;
			target.setPixel(rowOffset + rDrawingArea.getFirstRow(), colOffset + rDrawingArea.getFirstColumn(), avgRed, avgBlue, avgGreen);
		}
	}
}

/*
	drawFlippedImageInHalfSize:		This is to "shrink" the image by half of its original size,
									while flipping the image upside down and set pixels to
									target image
	Precondition:					Image should have even rows and columns and have valid pixels
	Postcondition:					target image will contain the shrinked, flipped (180) image
									based on the location of the previous rectangle
*/

void drawFlippedImageInHalfSize(Image& main, Rectangle& rDrawingArea, Rectangle& rPrev, Image& target)
{
	for (int row = rPrev.getMaxRow() - 1; row > rPrev.getFirstRow() + 1; row -= 2)
	{
		for (int col = rPrev.getMaxColumn() - 1; col > rPrev.getFirstColumn() + 1; col -= 2)
		{
			pixel p1 = main.getPixel(row, col);
			pixel p2 = main.getPixel(row - 1, col);
			pixel p3 = main.getPixel(row, col - 1);
			pixel p4 = main.getPixel(row - 1, col - 1);
			int avgRed = (p1.red + p2.red + p3.red + p4.red) / 4;
			int avgGreen = (p1.green + p2.green + p3.green + p4.green) / 4;
			int avgBlue = (p1.blue + p2.blue + p3.blue + p4.blue) / 4;

			int rowOffset = (row - rPrev.getFirstRow()) / 2;
			int colOffset = (col - rPrev.getFirstColumn()) / 2;
			target.setPixel(rDrawingArea.getMaxRow() - rowOffset,rDrawingArea.getMaxColumn() - colOffset, avgRed, avgBlue, avgGreen);
		}
	}
}