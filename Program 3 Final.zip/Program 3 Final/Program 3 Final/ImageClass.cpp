/*
	ImageClass.cpp
	Author:		Zachary Liong
	Purpose:	This is an implementation class, where all functions
				from the ImageClass.h will be implemented, which borrows
				some functions from ImageLib.h
*/
#include "ImageClass.h"
#include <iostream>
#include <cassert>

using namespace std;

//copy constructor
Image::Image(const Image& copy)
{
	mImage = CopyImage(copy.mImage);
}

//destructor
Image::~Image()
{
	DeallocateImage(mImage);
}

/*
	operator=:		Sets the private image data with
					the pic's private image data.
	Precondition:	Pic needs to be initialized and has
					a image data.
	Postcondition:	Returns the source's private data image
*/

Image& Image::operator=(const Image& pic)
{
	if (*this != pic)
	{
		DeallocateImage(mImage);
	}
	
	mImage = CopyImage(pic.mImage);
	return *this;
}

/*
	savePicture:	Outputs the private image and
					saves the image as "output.gif"
	Precondition:	image does have an data image value
	Postcondition:	Outputs the image into a file called
					"output.gif"
*/

void Image::savePicture()
{
	WriteGIF("output.gif", mImage);
}

/*
	getRows:		Retrieves the rows from the image variable
	Precondition:	image variable does exist and has valid int rows
	Postcondition:	Retrieves and returns the image.rows as an integer
*/

int Image::getRows() const
{
	return mImage.rows;
}

/*
	getColumns:		Retrieves the columns from the image variable
	Precondition:	image variable does exist and has valid int columns
	Postcondition:	Retrieves and returns the image.cols as an integer
*/

int Image::getColumns() const
{
	return mImage.cols;
}

/*
	getBlue:		Retrieves the byte value blue from
					private image data at row r and col c.
	Precondition:	Pic must be a valid, exisiting image that
					does have an actual pixel array
	Postcondition:	It will return the individual pixel's blue
					at r and c	
*/

int Image::getBlue( int r, int c) const
{
	return mImage.pixels[r][c].blue;
}

/*
	setBlue:		retrieves the individual pixel's blue byte data
					and modifies it
	Precondition:	The image variable has a valid, existing pixel array,
					int r and c should be within image's dimensions
	Postcondition:	Changes the pixel's blue value based on the int mod

*/

void Image::setBlue(pixel& pix, int value)
{
	pix.blue = value;
}

/*
	getRed:			Retrieves the byte value red from
					private image data at row r and col c.
	Precondition:	Pic must be a valid, exisiting image that
					does have an actual pixel array
	Postcondition:	It will return the individual pixel's red
					at r and c
*/

int Image::getRed(image pic, int r, int c) const
{
	return pic.pixels[r][c].red;

}

/*
	setRed:			retrieves the individual pixel's red byte data
					and modifies it
	Precondition:	The image variable has a valid, existing pixel array,
					int r and c should be within image's dimensions
	Postcondition:	Changes the pixel's red value based on the int mod

*/

void Image::setRed(pixel& pix, int value)
{
	pix.red = value;
}

/*
	ReadFromFile:	Reads the string and locates
					the GIF image in the current directory
	Precondition:	None
	Postcondition:	Method will read the image and stores into
					the private image data.
*/

image Image::ReadFromFile(string fileName)
{
	return mImage = ReadGIF(fileName);
}

/*
	getPixel:		This will access image's pixel array
					and will retrieve the individual pixel
	Precondition:	Rows and columns are valid and should be 
					within the boundaries of image's dimensions
	Postcondition:	Returns the individual pixel at row (r) and
					column (c).
*/

pixel& Image::getPixel(int r, int c) const
{
	return mImage.pixels[r][c];
}

/*
	setPixel:		Changes the source image individual
					pixel at row and column, which includes
					its colors to target's colors at r,c
	Precondition:	Both images should have the same dimension
					and that target pixel is valid and exist.
	Postcondition:	Return's the source's individual pixels with
					the target's individal pixels
*/

void Image::setPixel(int r, int c, int red, int blue, int green)
{
	
		mImage.pixels[r][c].blue = blue;
		mImage.pixels[r][c].red = red;
		mImage.pixels[r][c].green = green;
	
}

/*
	createBlankImage:	Creates an image variable based
						on integer rows and columns
	Precondition:		Rows (r) and Columns (c) will be used
						to determine the dimensions of the image
	Postcondition:		This will create a black image and stores
						into the private image data.
*/

image Image::createBlankImage(int r, int c)
{
	mImage = CreateImage(r, c);
	return mImage;
}

/*
	operator<:		Checks if the source's and target (pic)'s
					dimensions are less than each other
	Precondition:	Image class's should have valid rows and columns
	Postcondition:	Returns a true of false value if the source's dimension
					is less than pic's dimension
*/

bool Image::operator<(const Image& pic) const
{
	int oriPic = mImage.cols * mImage.rows;
	int targetPic = pic.getColumns() * pic.getRows();
	return oriPic < targetPic;
}

/*
	operator>:		Checks if the source's and target (pic)'s
					dimensions are greater than each other
	Precondition:	Image class's should have valid rows and columns
	Postcondition:	Returns a true of false value if the source's dimension
					is greater than pic's dimension
*/

bool Image::operator>(const Image& pic) const
{
	int oriPic = mImage.cols * mImage.rows;
	int targetPic = pic.getColumns() * pic.getRows();
	return oriPic > targetPic;
}

/*
	operator==:		compares two Image classes and checks
					every pixel for any differences
	Precondition:	Both Image classes' private image should
					be valid and initialized. Pixel 2d array
					must be filled and initialized
	Postcondition:	Returns true or false if the Image classes
					are not the same
*/

bool Image::operator==(const Image& pic) const
{
	int counter = 0;
	int total = mImage.rows * mImage.cols;
	if (mImage.rows == pic.mImage.rows && mImage.cols == pic.mImage.cols)
	{
		for (int row = 0; row < mImage.rows; row++)
		{
			for (int col = 0; col < mImage.cols; col++)
			{
				counter++;
				if (counter == total)
				{
					return true;
				}
				else
				{
					if (mImage.pixels[row][col].blue != pic.mImage.pixels[row][col].blue ||
						mImage.pixels[row][col].red != pic.mImage.pixels[row][col].red ||
						mImage.pixels[row][col].green != pic.mImage.pixels[row][col].green)
					{
						return false;
					}
				}
			}
		}
	}
		return false;
}


/*
	operator!=:		compares two Image classes and checks
					every pixel for any differences
	Precondition:	Both Image classes' private image should
					be valid and initialized. Pixel 2d array
					must be filled and initialized
	Postcondition:	Returns true if the Image classes are the
					same, while return false if a single individual
					pixel is same
*/

bool Image::operator!=(const Image& pic) const
{

	if (mImage.rows == pic.mImage.rows && mImage.cols == pic.mImage.cols)
	{
		int counter = 0;
		int totalPixel = mImage.cols * mImage.rows;
		for (int row = 0; row < mImage.rows; row++)
		{
			for (int col = 0; col < mImage.cols; col++)
			{
				counter++;
				if (counter == totalPixel)
				{
					return true;
				}
				else
				{
					if (mImage.pixels[row][col].blue == pic.mImage.pixels[row][col].blue &&
						mImage.pixels[row][col].red == pic.mImage.pixels[row][col].red &&
						mImage.pixels[row][col].green == pic.mImage.pixels[row][col].green)
					{
						return false;
					}
				}
			}
		}
	}
	return true;
}

/*
	mirrorImage:	Takes an image and mirrors it
	Precondition:	The Image class's image data does
					exist (pixel array, rows, and columns)
	Postcondtion:	Returns a new Image class that has
					mirrored image of the original
*/

Image Image::mirrorImage()
{
	Image copy = *this;
	
	for (int row = 0; mImage.rows > row; row++)
	{
		for (int col = 0; mImage.cols / 2 > col; col++)
		{
			//this saves the current selected pixel (original)
			pixel temp = mImage.pixels[row][col];
			//this will swap the pixels around using columns to create the mirror images
			int swapColumns = mImage.cols - col - 1;
			mImage.pixels[row][col] = mImage.pixels[row][swapColumns];
			mImage.pixels[row][swapColumns] = temp;
		}
	}
	return copy;
}

/*
	operator<<:		Prints out the image's rows and columns statement
	Precondition:	Image's rows and columns does exist or initialized beforehand
	Postcondition:	Returns a print statement that contains image's rows and columns.
*/

ostream& operator<<(ostream& ostr, const Image& im)
{
	ostr << "Rows x Cols: " << im.getRows() << " x " << im.getColumns() << "\n";
	return ostr;
}
