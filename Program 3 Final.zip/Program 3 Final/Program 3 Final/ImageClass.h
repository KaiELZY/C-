/*
	ImageClass.h
	Author:		Zachary Liong
	Purpose:	Creates a Image Class that will be used
				to hide the sensitive data from the ImageLib.h
				and be used in the Main.cpp
*/
#include "ImageLib.h"
using namespace std;
class Image
{
public:
	//default constructor
	Image() {
		mImage = this->createBlankImage(0, 0);
	}
	//copy constructor
	Image(const Image& copy);

	//destructor
	~Image();

	/*
		operator=:		Sets the private image data with
						the pic's private image data.
		Precondition:	Pic needs to be initialized and has
						a image data.
		Postcondition:	Returns the source's private data image
	*/

	Image& operator=(const Image& pic);

	/*
		savePicture:	Outputs the private image and
						saves the image as "output.gif"
		Precondition:	image does have an data image value
		Postcondition:	Outputs the image into a file called
						"output.gif"
	*/

	void savePicture();

	/*
		getRows:		Retrieves the rows from the image variable
		Precondition:	image variable does exist and has valid int rows
		Postcondition:	Retrieves and returns the image.rows as an integer
	*/

	int getRows() const;

	/*
		getColumns:		Retrieves the columns from the image variable
		Precondition:	image variable does exist and has valid int columns
		Postcondition:	Retrieves and returns the image.cols as an integer
	*/

	int getColumns() const;

	/*
		getBlue:		Retrieves the byte value blue from
						private image data at row r and col c.
		Precondition:	Pic must be a valid, exisiting image that
						does have an actual pixel array
		Postcondition:	It will return the individual pixel's blue
						at r and c
	*/

	int getBlue( int r, int c) const;

	/*
		setBlue:		retrieves the individual pixel's blue byte data
						and modifies it
		Precondition:	The image variable has a valid, existing pixel array,
						int r and c should be within image's dimensions
		Postcondition:	Changes the pixel's blue value based on the int mod

	*/

	void setBlue(pixel& pix, int value);

	/*
		getRed:			Retrieves the byte value red from
						private image data at row r and col c.
		Precondition:	Pic must be a valid, exisiting image that
						does have an actual pixel array
		Postcondition:	It will return the individual pixel's red
						at r and c
	*/

	int getRed(image pic, int r, int c) const;

	/*
		setRed:			retrieves the individual pixel's red byte data
						and modifies it
		Precondition:	The image variable has a valid, existing pixel array,
						int r and c should be within image's dimensions
		Postcondition:	Changes the pixel's red value based on the int mod

	*/

	void setRed(pixel& pix, int value);

	/*
		ReadFromFile:	Reads the string and locates
						the GIF image in the current directory
		Precondition:	None
		Postcondition:	Method will read the image and stores into
						the private image data.
	*/

	image ReadFromFile(string fileName);

	/*
		getPixel:		This will access image's pixel array
						and will retrieve the individual pixel
		Precondition:	Rows and columns are valid and should be
						within the boundaries of image's dimensions
		Postcondition:	Returns the individual pixel at row (r) and
						column (c).
	*/

	pixel& getPixel(int r, int c) const;

	/*
		setPixel:		Changes the source image individual
						pixel at row and column, which includes
						its colors to target's colors at r,c
		Precondition:	Both images should have the same dimension
						and that target pixel is valid and exist.
		Postcondition:	Return's the source's individual pixels with
						the target's individal pixels
	*/

	void setPixel(int r, int c, int red, int blue, int green);

	/*
		createBlankImage:	Creates an image variable based
							on integer rows and columns
		Precondition:		Rows (r) and Columns (c) will be used
							to determine the dimensions of the image
		Postcondition:		This will create a black image and stores
							into the private image data.
	*/

	image createBlankImage(int r, int c);

	//overload <<

	friend ostream& operator<<(ostream& ostr, const Image& im);
	
	//overload <

	/*
		operator<:		Checks if the source's and target (pic)'s
						dimensions are less than each other
		Precondition:	Image class's should have valid rows and columns
		Postcondition:	Returns a true of false value if the source's dimension
						is less than pic's dimension
	*/

	bool operator<(const Image&) const;

	//overload >

	/*
		operator>:		Checks if the source's and target (pic)'s
						dimensions are greater than each other
		Precondition:	Image class's should have valid rows and columns
		Postcondition:	Returns a true of false value if the source's dimension
						is greater than pic's dimension
	*/

	bool operator>(const Image&) const;

	//overload ==

	/*
		operator==:		compares two Image classes and checks
						every pixel for any differences
		Precondition:	Both Image classes' private image should
						be valid and initialized. Pixel 2d array
						must be filled and initialized
		Postcondition:	Returns true or false if the Image classes
						are not the same
	*/

	bool operator==(const Image&) const;

	//overload !=

	/*
		operator!=:		compares two Image classes and checks
						every pixel for any differences
		Precondition:	Both Image classes' private image should
						be valid and initialized. Pixel 2d array
						must be filled and initialized
		Postcondition:	Returns true if the Image classes are the
						same, while return false if a single individual
						pixel is same
	*/

	bool operator!=(const Image&) const;

	//mirror Method

	/*
		mirrorImage:	Takes an image and mirrors it
		Precondition:	The Image class's image data does
						exist (pixel array, rows, and columns)
		Postcondtion:	Returns a new Image class that has
						mirrored image of the original
	*/

	Image mirrorImage();
private:
	
	image mImage;
};