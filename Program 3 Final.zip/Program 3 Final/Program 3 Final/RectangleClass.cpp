#include "RectangleClass.h"
#include<iostream>

/*
	RectangleClass.cpp
	Author:		Zachary Liong
	Purpose:	This is an implementation class, where all functions
				from the RectangleClass.h will be implemented, 
*/

/*
	operator<<:		Return a readable, human language to user
					about the dimensions of the rectangle
	Precondition:	None (default would be 0 either why when initialized)
	Postcondition:	Return ostr with the print statement of dimensions
					of rectangle
*/

ostream& operator<<(ostream& ostr, const Rectangle& r)
{
	ostr << "The dimensions of this rectangle is( length x width) " << r.getMaxRow() << " x " << r.getMaxColumn() << endl;
	return ostr;
}

/*
	Rectangle():	Creates a rectangle with 0 rows and 0 columns,
					basically (0,0,0,0) = (x1, x2, y1, y2)
	Precondition:	None
	Postcondition:	Returns a rectnagle with (0,0,0,0) = (x1,x2,y1,y2)	
*/

Rectangle::Rectangle()
{
	firstRow = 0;
	firstColumn = 0;
	maxRow = 0;
	maxColumn = 0;
}

/*
	Rectangle:		Replaces the current values of the rectangle with
					parameter values
	Precondition:	n >= 0, no negative values
	Postcondition:	Replaces the current values of the rectangle with
					parameter values

*/
Rectangle::Rectangle(int firstX, int lastX, int firstY, int lastY)
{
	firstRow = firstX;
	firstColumn = firstY;
	maxRow = lastX;
	maxColumn = lastY;
}

/*
	Rectangle:		Copies the param rectangle and replaces the current
					values with the copy's
	Precondition:	Assume that copy does have values, otherwiser
					it will be a result of default constructor
	Postcondtion:	Replaces current values with the copy's values
*/

Rectangle::Rectangle(const Rectangle& copy)
{
	firstRow = copy.firstRow;
	firstColumn = copy.firstColumn;
	maxRow = copy.maxRow;
	maxColumn = copy.maxColumn;
}

/*
	getFirstRow:	Returns the first row
	PreconditionL	None
	Postcondition:	Returns the current first row
*/	

int Rectangle::getFirstRow() const
{
	return firstRow;
}

/*
	setFirstRow:	Sets the current value of first
					row with r
	Precondition:	Any natural numbers, perferably positive
	Postcondition:	Sets the current value with int r
*/

void Rectangle::setFirstRow(int r)
{
	firstRow = r;
}

/*
	getFirstColumn:	Returns the first column
	PreconditionL	None
	Postcondition:	Returns the current first column
*/

int Rectangle::getFirstColumn() const
{
	return firstColumn;
}

/*
	setFirstColumn:	Sets the current value of first
					column with c
	Precondition:	Any natural numbers, perferably positive
	Postcondition:	Sets the current value with int c
*/

void Rectangle::setFirstColumn(int c)
{
	firstColumn = c;
}

/*
	getMaxRow:		Returns the max row
	PreconditionL	None
	Postcondition:	Returns the current max row
*/

int Rectangle::getMaxRow() const
{
	return maxRow;
}

/*
	setMaxRow:		Sets the current value of max
					row with r
	Precondition:	Any natural numbers, perferably positive
	Postcondition:	Sets the current value with int r
*/

void Rectangle::setMaxRow(int r)
{
	maxRow = r;
}

/*
	getMaxColumn:	Returns the max column
	PreconditionL	None
	Postcondition:	Returns the current max column
*/

int Rectangle::getMaxColumn() const
{
	return maxColumn;
}

/*
	setMaxColumn:	Sets the current value of max
					column with c
	PreconditionL	Any natural numbers, perferably positive
	Postcondition:	Sets the current value with int c
*/

void Rectangle::setMaxColumn(int c)
{
	maxColumn = c;
}

/*
	isValid:		Checks if x1(firstRow) is greater than
					x2(maxRow) and y1(firstColumn) is greater 
					than y2(maxColumn)
	Precondtion:	Any integer values
	Postcondition:	Returns true or false when both statements are true
					or false
*/
bool Rectangle::isValid()
{
	return firstRow >= maxRow && firstColumn > maxColumn;
}

/*
	operator==:		Returns true if all of the values matches with r's values
	Precondition:	None
	Postcondition:	Returns true if all values matches with r's values, otherwise
					return false
*/

bool Rectangle::operator==(const Rectangle& r) const
{
	return firstRow == r.firstRow && maxRow == r.maxRow && firstColumn == r.firstColumn && maxColumn == r.maxColumn;
}

/*
	operator!=:		Returns true if one of the values does not match with r's values
	Precondition:	None
	Postcondition:	Returns true if one of the values  does not match with r's values, otherwise
					return false
*/

bool Rectangle::operator!=(const Rectangle& r) const
{
	return firstRow != r.firstRow || maxRow != r.maxRow || firstColumn != r.firstColumn || maxRow != r.maxColumn;
}
