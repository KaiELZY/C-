#pragma once
#include <iostream>
using namespace std;
/*
	RectangleClass.h
	Author:		Zachary Liong
	Purpose:	This is a header class that will store the
				coordinates of the rectangles, which is to
				book keep all the borders of images
*/
class Rectangle
{
public:
	//default constructor


	/*
		Rectangle():	Creates a rectangle with 0 rows and 0 columns,
						basically (0,0,0,0) = (x1, x2, y1, y2)
		Precondition:	None
		Postcondition:	Returns a rectnagle with (0,0,0,0) = (x1,x2,y1,y2)
	*/
	Rectangle();

	//overload constructor

	/*
		Rectangle:		Replaces the current values of the rectangle with
						parameter values
		Precondition:	n >= 0, no negative values
		Postcondition:	Replaces the current values of the rectangle with
						parameter values

	*/

	Rectangle(int firstX, int lastX, int firstY, int lastY);
	
	//copy constructor
	
	/*
		Rectangle:		Copies the param rectangle and replaces the current
						values with the copy's
		Precondition:	Assume that copy does have values, otherwiser
						it will be a result of default constructor
		Postcondtion:	Replaces current values with the copy's values
	*/

	Rectangle(const Rectangle& copy);
	

	//Accessors and Mutators

	/*
		getFirstRow:	Returns the first row
		PreconditionL	None
		Postcondition:	Returns the current first row
	*/

	int getFirstRow() const;

	/*
		setFirstRow:	Sets the current value of first
						row with r
		Precondition:	Any natural numbers, perferably positive
		Postcondition:	Sets the current value with int r
	*/

	void setFirstRow(int r);

	/*
		getFirstColumn:	Returns the first column
		PreconditionL	None
		Postcondition:	Returns the current first column
	*/

	int getFirstColumn() const;

	/*
		setFirstColumn:	Sets the current value of first
						column with c
		Precondition:	Any natural numbers, perferably positive
		Postcondition:	Sets the current value with int c
	*/

	void setFirstColumn(int c);

	/*
		getMaxRow:		Returns the max row
		PreconditionL	None
		Postcondition:	Returns the current max row
	*/

	int getMaxRow() const;

	/*
		setMaxRow:		Sets the current value of max
						row with r
		Precondition:	Any natural numbers, perferably positive
		Postcondition:	Sets the current value with int r
	*/

	void setMaxRow(int r);

	/*
		getMaxColumn:	Returns the max column
		PreconditionL	None
		Postcondition:	Returns the current max column
	*/

	int getMaxColumn() const;

	/*
		setMaxColumn:	Sets the current value of max
						column with c
		PreconditionL	Any natural numbers, perferably positive
		Postcondition:	Sets the current value with int c
	*/

	void setMaxColumn(int c);

	/*
		isValid:		Checks if x1(firstRow) is greater than
						x2(maxRow) and y1(firstColumn) is greater
						than y2(maxColumn)
		Precondtion:	Any integer values
		Postcondition:	Returns true or false when both statements are true
						or false
	*/

	bool isValid();

	/*
		operator<<:		Return a readable, human language to user
						about the dimensions of the rectangle
		Precondition:	None (default would be 0 either why when initialized)
		Postcondition:	Return ostr with the print statement of dimensions
						of rectangle
	*/

	friend ostream& operator<<(ostream& ostr, const Rectangle& r);
	
	/*
		operator==:		Returns true if all of the values matches with r's values
		Precondition:	None
		Postcondition:	Returns true if all values matches with r's values, otherwise
						return false
	*/

	bool operator==(const Rectangle&) const;

	bool operator!=(const Rectangle&) const;
private:
	int firstRow;
	int firstColumn;
	int maxRow;
	int maxColumn;
};